from .analise import analisar_pacotes
