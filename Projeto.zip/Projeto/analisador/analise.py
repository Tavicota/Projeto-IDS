import subprocess
import time
import socket
import struct
from sklearn import tree
from capturador.captura import ip_to_features
import logging

logging.basicConfig(
    level=logging.INFO,  # Define o nível mínimo de severidade das mensagens a serem registradas
    format='%(asctime)s - %(message)s',  # Formato das mensagens de log
    handlers=[
        logging.StreamHandler(),  # Envia logs para a saída padrão (tela)
        logging.FileHandler('/home/cliente/Desktop/IDS/bloqueados.log', mode='a')  # Envia logs para o arquivo especificado
    ]
)


# Definição das características e rótulos para treinamento
features = [
    ip_to_features('192.168.0.247') + [22, 6],    # IP: 192.168.0.1, Porta: 22 (SSH), Protocolo: TCP (6)
    ip_to_features('192.168.0.247') + [23, 17],  # IP: 192.168.0.2, Porta: 1560, Protocolo: TCP (6)
    ip_to_features('192.168.0.247') + [53, 6],   # IP: 192.168.0.3, Porta: 53 (DNS), Protocolo: UDP (17)
    ip_to_features('192.168.0.247') + [443, 6],   # IP: 192.168.0.4, Porta: 443 (HTTPS), Protocolo: TCP (6)
    ip_to_features('192.168.0.247') + [22, 17],# IP: 192.168.0.5, Porta: 12000, Protocolo: UDP (17)
    ip_to_features('192.168.0.247') + [1560, 17], # IP: 192.168.0.7, Porta: 1560, Protocolo: TCP (6)
    ip_to_features('192.168.0.247') + [23, 17] # IP: 192.168.0.7, Porta: 12000, Protocolo: UDP (17)
]
labels = [0, 1, 0, 0, 1, 1, 1]  # 0 para tráfego normal, 1 para tráfego suspeito

# Criação e treinamento do classificador
classif = tree.DecisionTreeClassifier()
classif.fit(features, labels)

def analisar_pacotes(pacotes):
    for packet in pacotes:
        # Processamento do pacote (extração de informações)
        ip_header = packet[14:34]  # Cabeçalho IP (20 bytes) + Cabeçalho Ethernet (14 bytes)
        ip_origem = ip_header[12:16]
        porta_destino = struct.unpack('!H', ip_header[2:4])[0]
        protocolo_num = ip_header[9]

        # Converte IP de origem para string
        ip_origem_str = '.'.join(map(str, ip_origem))

        # Cria as features para predição
        features = ip_to_features(ip_origem_str) + [porta_destino, protocolo_num]
        x = classif.predict([features])

        if x == 1:
            # Ação: Bloquear IP de origem usando ufw
            comando_bloqueio = [
                '/usr/sbin/ufw', 'deny', 'proto', 'tcp',
                'from', ip_origem_str, 'to', 'any', 'port', str(porta_destino)
            ]
            try:
                subprocess.run(comando_bloqueio, check=True)
                logging.info(f"Tráfego suspeito detectado de {ip_origem_str}:{porta_destino}. Bloqueio aplicado.")
                # Aguarda 1 minuto antes de remover o bloqueio
                time.sleep(5)
                comando_remocao = [
                    '/usr/sbin/ufw', 'delete', 'deny', 'proto', 'tcp',
                    'from', ip_origem_str, 'to', 'any', 'port', str(porta_destino)
                ]
                subprocess.run(comando_remocao, check=True)
                logging.info(f"Bloqueio removido para {ip_origem_str}:{porta_destino}.")
            except subprocess.CalledProcessError as e:
                logging.error(f"Erro ao executar comando ufw: {e}")
        else:
            logging.info(f"Tráfego normal de {ip_origem_str}:{porta_destino}.")


